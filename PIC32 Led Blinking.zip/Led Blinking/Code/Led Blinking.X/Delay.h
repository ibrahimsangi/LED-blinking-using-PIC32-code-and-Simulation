
/*
 * File:   Delay.h
 *
 * Author: IBRAHIM LABS
 *
 * Website: http://ibrahimlabs.blogspot.com/
 *
 * Created on September 5, 2013, 9:24 AM
 */

#ifndef DELAY_H
#define	DELAY_H

#ifdef	__cplusplus
extern "C" {
#endif

    void GeneralDelay(unsigned int DelayValue);


#ifdef	__cplusplus
}
#endif

#endif	/* DELAY_H */

