/* 
 * File:   Delay.c
 * Author: IBRAHIM LABS
 *
 * Website: http://ibrahimlabs.blogspot.com/
 *
 * Created on September 5, 2013, 9:21 AM
 */

#include "GenericTypeDefs.h"

void GeneralDelay(unsigned int DelayValue)
{
    unsigned int i = 0;
    for ( ; i < DelayValue; i++)
        ;
}

